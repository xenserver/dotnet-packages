﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]

[assembly: Guid("dfe69232-1753-4fad-acf3-e8a9bbf434f1")]
