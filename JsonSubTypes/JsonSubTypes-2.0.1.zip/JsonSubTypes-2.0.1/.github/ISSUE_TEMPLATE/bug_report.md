---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

### Source/destination types

```csharp
// Put the types you are serializing or deserializing here
```

### Source/destination JSON

```javascript
{"message":"Place your serialized or deserialized JSON here"}
```

### Expected behavior

<!-- What did you expect to happen? -->

### Actual behavior

<!-- What happened instead? -->

### Steps to reproduce

```csharp
// Your calls to here
```
