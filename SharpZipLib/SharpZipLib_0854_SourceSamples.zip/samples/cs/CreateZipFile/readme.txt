createzipfile
-------------

Usage:

  createzipfile [directoryname] [zipfilename]

  will create zipfilename and store all files in the directory [directoryname]
  in it.
  
  (btw. [directoryname] is a directoryname like C:\testdir not *.* or other
   wildcards)
  
